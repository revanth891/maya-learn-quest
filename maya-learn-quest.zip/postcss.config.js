export default {
  plugins: {
    "postcss-import": {},
    tailwindcss: {},
    "postcss-preset-env": { stage: 3, preserve: true },
  },
};
